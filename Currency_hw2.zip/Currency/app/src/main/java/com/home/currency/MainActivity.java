package com.home.currency;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ntdEdit;
    Button goBtn;
    String title;
    String message;
    float result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
    }
    public void findViews(){
        ntdEdit = findViewById(R.id.ntd);
        goBtn = findViewById(R.id.button);
        result = 0f;
        goBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    result = (float) (Integer.parseInt(ntdEdit.getText().toString())) / 30.9f;
                } catch (NumberFormatException ne){

                }
                if (result > 0f) {
                    title = "Result";
                    message = "USD is "+String.format("%.4f",result);
                } else{
                    title = "Problem";
                    message = "Please enter your NTD amount";
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(title)
                        .setMessage(message)
                        .setPositiveButton("OK",null)
                        .show();
            }
        });
    }
}
