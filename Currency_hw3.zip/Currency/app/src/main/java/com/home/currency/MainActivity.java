package com.home.currency;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ntdEdit;
    Button goBtn;
    String title;
    String message;
    float result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
    }
    public void findViews(){
        ntdEdit = findViewById(R.id.ntd);
        goBtn = findViewById(R.id.button);
        result = 0f;
        goBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    try {
                        result = (float) (Integer.parseInt(ntdEdit.getText().toString())) / 30.9f;
                    } catch (NumberFormatException ne) {
                        result = 0f;
                    }
                if (result > 0f) {
                    title = getString(R.string.result);
                    message = getString(R.string.usd_is)+String.format("%.4f",result);
                } else{
                    title = getString(R.string.problem);
                    message = getString(R.string.please_enter_ntd);
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(title)
                        .setMessage(message)
                        .setPositiveButton(R.string.ok,null)
                        .show();
            }
        });
    }
}
